package DefinaAnInterfacePerson;

public interface Person {
    String getName();
    int getAge();
}
