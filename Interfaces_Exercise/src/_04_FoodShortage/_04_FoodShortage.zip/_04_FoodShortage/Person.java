package _04_FoodShortage;

public interface Person {
    String getName();
    int getAge();
}
