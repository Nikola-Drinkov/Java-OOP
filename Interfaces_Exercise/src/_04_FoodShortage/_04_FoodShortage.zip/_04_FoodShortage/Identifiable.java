package _04_FoodShortage;

public interface Identifiable {
    String getId();
}
