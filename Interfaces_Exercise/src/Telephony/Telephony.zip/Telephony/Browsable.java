package Telephony;

public interface Browsable {
    String browse();
}
